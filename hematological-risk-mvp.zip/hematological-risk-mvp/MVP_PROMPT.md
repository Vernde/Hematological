# Copy-Paste MVP Prompt

Build a working, presentation-ready Python desktop MVP for my thesis:

**AN ENHANCEMENT OF DECISION TREE ALGORITHM THROUGH ENTROPY-BASED FEATURE OPTIMIZATION APPLIED IN HEMATOLOGICAL RISK CLASSIFICATION**

Use the attached thesis flowchart as the functional reference. The system must follow this pipeline:

INPUT → DATA PROCESSING → ENTROPY COMPUTATION → FEATURE OPTIMIZATION → DECISION TREE CONSTRUCTION → CLASSIFICATION & EVALUATION → OUTPUT.

## Technology

- Python 3.10+
- pandas + NumPy for data processing
- scikit-learn for the Decision Tree and evaluation
- Matplotlib for charts/visualization
- Tkinter for the desktop UI and Matplotlib embedding
- joblib for optional model persistence
- No Django, Flask, FastAPI, React, or database is required for this MVP.
- The application must work offline after dependencies are installed.

## Dataset

Use a public CBC/anemia classification dataset as the real-data option. A suitable reference dataset is the Kaggle **Anemia Types Classification** dataset, which contains HGB, PLT, WBC, RBC, MCV, MCH, MCHC, PDW, PCT and a Diagnosis label. A downloadable CSV mirror is also available from the GitHub repository used by the included `download_dataset.py` helper.

Do not claim that this public dataset contains clinically validated Low/Moderate/High risk labels. The actual ML target should be the dataset's `Diagnosis` label. If the UI displays Low/Moderate/High, make it explicitly a configurable academic/demo grouping and not a clinical severity standard.

Also provide an included synthetic CSV so the application can run without internet access.

## Required input features

At minimum support:

- HGB — Hemoglobin
- WBC — White Blood Cell Count
- RBC — Red Blood Cell Count
- PLT — Platelet Count
- MCV
- MCH
- MCHC

Support aliases such as `Hemoglobin`, `White_Blood_Cells`, `Red_Blood_Cells`, `Platelet_Count`, and `PlT` when loading external CSV files.

## Data Processing

Implement:

1. CSV loading
2. Column-name normalization
3. Numeric conversion
4. Missing-value handling
5. Duplicate removal
6. Cleaned dataset preview
7. Stratified train/test split with a fixed random seed for reproducibility

Show before/after record counts and missing values in the UI.

## Entropy Computation

Implement Shannon entropy explicitly:

Entropy(S) = -Σ p_i log2(p_i)

For every candidate feature, calculate information gain by comparing parent entropy with weighted child entropy. Because CBC features are continuous, discretize each feature into quantile bins before calculating the entropy-based information gain.

Show a table containing:

- Feature
- Information Gain
- Rank

Also show a Matplotlib bar chart of the information-gain ranking.

## Feature Optimization

Use information gain to select the strongest features before Decision Tree construction.

Requirements:

- Configurable minimum information-gain threshold
- Configurable maximum number of selected features
- Save/display the selected feature list
- Make it easy to explain that the optimization stage removes weak/redundant inputs before classification

Do not pretend that information gain itself proves a feature is clinically important; it is a dataset/model-selection criterion.

## Decision Tree Construction

Train two models:

### Baseline
Decision Tree using all candidate features.

### Optimized
Decision Tree using only the selected entropy-ranked features.

Both should use:

`criterion='entropy'`

Use a reproducible random state and a configurable maximum depth.

Compare the two models using the same held-out test set.

## Classification and Evaluation

Display:

- Accuracy
- Weighted precision
- Weighted recall
- Weighted F1-score
- Confusion matrix
- Per-class metrics
- Class distribution

Do not hard-code an accuracy number. Calculate it from the actual test set.

If the optimized model performs worse than the baseline, show that honestly. The MVP must demonstrate the method rather than manufacture an improvement.

## Prediction screen

Create a form for a new CBC record using:

- HGB
- WBC
- RBC
- PLT
- MCV
- MCH
- MCHC

When the user clicks **Classify**, show:

- predicted dataset class
- predicted class probability
- selected features used by the optimized tree
- an academic/demo risk grouping if configured

Include a visible disclaimer:

"For academic demonstration only. This is not a medical diagnosis or clinical decision-support system."

## Matplotlib UI/dashboard

Create a clean desktop dashboard using Tkinter with embedded Matplotlib figures.

Tabs/sections:

1. Dashboard
2. Data Processing
3. Entropy / Feature Optimization
4. Decision Tree
5. Classify New Sample
6. Evaluation

Dashboard cards should show:

- Number of records
- Number of classes
- Baseline accuracy
- Optimized accuracy
- Number of selected features

Charts:

- class distribution
- information gain ranking
- confusion matrix
- baseline vs optimized accuracy

## Project structure

Use a modular structure:

```text
hematological-risk-mvp/
├── app/
│   ├── config.py
│   ├── data_processing.py
│   ├── dataset.py
│   ├── entropy_optimizer.py
│   ├── evaluation.py
│   ├── gui.py
│   └── model.py
├── data/
│   ├── README.md
│   └── sample_hematology.csv
├── docs/
│   └── thesis_demo_notes.md
├── models/
├── download_dataset.py
├── MVP_PROMPT.md
├── requirements.txt
├── run.py
└── README.md
```

## README requirements

Write a complete README containing:

- thesis title
- system purpose
- architecture/flow mapping
- installation steps for Windows
- virtual environment commands
- dataset source and provenance notes
- how to download the public CSV
- how to run the application
- explanation of entropy
- explanation of information gain
- explanation of feature optimization
- explanation of Decision Tree construction
- explanation of evaluation metrics
- presentation/demo sequence
- limitations and medical disclaimer

## Important thesis-defense wording

The system should be described as an **academic machine-learning prototype for hematological classification**. Do not call it a validated medical diagnostic system.

The key enhancement being demonstrated is the additional entropy-based feature optimization stage before Decision Tree construction, followed by a comparison against a baseline tree using all candidate features.

## Deliverables

Return a complete runnable project, not pseudocode. All imports must work, the included sample dataset must run offline, and the README must explain every step needed to demonstrate the system.
