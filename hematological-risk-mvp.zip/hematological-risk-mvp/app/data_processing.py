from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


def load_dataset(path: str | Path):
    df = pd.read_csv(path)
    # Normalize common names from CBC datasets.
    aliases = {
        'Hemoglobin': 'HGB', 'hemoglobin': 'HGB', 'hemoglobin_g_dl': 'HGB',
        'White_Blood_Cells': 'WBC', 'white_blood_cells': 'WBC', 'wbc_count': 'WBC',
        'Red_Blood_Cells': 'RBC', 'red_blood_cells': 'RBC', 'rbc_count': 'RBC',
        'Platelet_Count': 'PLT', 'platelet_count': 'PLT', 'PlT': 'PLT',
        'Diagnosis': 'Diagnosis', 'diagnosis': 'Diagnosis'
    }
    df = df.rename(columns={c: aliases.get(c, c) for c in df.columns})
    return df


def clean_data(df: pd.DataFrame, features: list[str], target: str):
    work = df.copy()
    needed = [c for c in features + [target] if c in work.columns]
    work = work[needed]
    for col in features:
        if col in work:
            work[col] = pd.to_numeric(work[col], errors='coerce')
    work = work.dropna(subset=[c for c in features + [target] if c in work.columns])
    work = work.drop_duplicates().reset_index(drop=True)
    return work


def split_data(df, features, target, test_size=0.2, random_state=42):
    X = df[features]
    y = df[target]
    return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=y)
