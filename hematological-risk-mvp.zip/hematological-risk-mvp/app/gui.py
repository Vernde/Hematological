import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from sklearn.model_selection import train_test_split

from .config import FEATURES, TARGET, SAMPLE_DATA, RISK_MAP
from .dataset import generate_sample_dataset
from .data_processing import load_dataset, clean_data
from .model import train

class App:
    def __init__(self, root):
        self.root = root
        self.root.title('Hematological Risk Classification — Entropy-Optimized Decision Tree')
        self.root.geometry('1250x780')
        self.root.minsize(1050, 700)
        self.df = None
        self.result = None
        self.test_data = None
        self._setup_style()
        self._build_ui()
        self.load_and_train(SAMPLE_DATA)

    def _setup_style(self):
        style = ttk.Style()
        try: style.theme_use('clam')
        except tk.TclError: pass
        style.configure('TNotebook.Tab', padding=[14, 8])
        style.configure('Header.TLabel', font=('Segoe UI', 20, 'bold'))
        style.configure('Sub.TLabel', font=('Segoe UI', 10))
        style.configure('Card.TLabel', font=('Segoe UI', 11, 'bold'))

    def _build_ui(self):
        header = ttk.Frame(self.root, padding=18)
        header.pack(fill='x')
        ttk.Label(header, text='Hematological Risk Classification', style='Header.TLabel').pack(anchor='w')
        ttk.Label(header, text='Decision Tree enhanced through entropy-based feature optimization | Academic MVP', style='Sub.TLabel').pack(anchor='w')
        bar = ttk.Frame(header); bar.pack(fill='x', pady=(12, 0))
        ttk.Button(bar, text='Load CSV Dataset', command=self.load_csv).pack(side='left')
        ttk.Button(bar, text='Retrain Model', command=self.retrain).pack(side='left', padx=8)
        self.status = ttk.Label(bar, text='Ready', style='Sub.TLabel'); self.status.pack(side='right')

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill='both', expand=True, padx=14, pady=(0, 14))
        self.dashboard = ttk.Frame(self.nb, padding=14)
        self.data_tab = ttk.Frame(self.nb, padding=14)
        self.entropy_tab = ttk.Frame(self.nb, padding=14)
        self.tree_tab = ttk.Frame(self.nb, padding=14)
        self.classify_tab = ttk.Frame(self.nb, padding=14)
        self.eval_tab = ttk.Frame(self.nb, padding=14)
        for tab, name in [(self.dashboard,'Dashboard'),(self.data_tab,'Data Processing'),(self.entropy_tab,'Entropy / Features'),(self.tree_tab,'Decision Tree'),(self.classify_tab,'Classify New'),(self.eval_tab,'Evaluation')]:
            self.nb.add(tab, text=name)
        self._build_dashboard(); self._build_data(); self._build_entropy(); self._build_tree(); self._build_classify(); self._build_eval()

    def _build_dashboard(self):
        self.metrics = ttk.Frame(self.dashboard); self.metrics.pack(fill='x')
        self.metric_labels = {}
        for key, title in [('rows','Rows'),('classes','Classes'),('base','Baseline Accuracy'),('opt','Optimized Accuracy'),('selected','Selected Features')]:
            card = ttk.LabelFrame(self.metrics, text=title, padding=12); card.pack(side='left', fill='both', expand=True, padx=5)
            lab = ttk.Label(card, text='—', font=('Segoe UI', 17, 'bold')); lab.pack()
            self.metric_labels[key] = lab
        self.chart_frame = ttk.Frame(self.dashboard); self.chart_frame.pack(fill='both', expand=True, pady=12)

    def _build_data(self):
        ttk.Label(self.data_tab, text='Cleaned dataset preview', style='Card.TLabel').pack(anchor='w')
        self.data_text = tk.Text(self.data_tab, height=25, font=('Consolas', 9)); self.data_text.pack(fill='both', expand=True, pady=8)
        self.data_info = ttk.Label(self.data_tab, text=''); self.data_info.pack(anchor='w')

    def _build_entropy(self):
        left = ttk.Frame(self.entropy_tab); left.pack(side='left', fill='both', expand=True)
        ttk.Label(left, text='Information Gain Ranking', style='Card.TLabel').pack(anchor='w')
        self.entropy_text = tk.Text(left, font=('Consolas', 10), width=55); self.entropy_text.pack(fill='both', expand=True, pady=8)
        right = ttk.Frame(self.entropy_tab); right.pack(side='right', fill='both', expand=True)
        self.entropy_chart = ttk.Frame(right); self.entropy_chart.pack(fill='both', expand=True)

    def _build_tree(self):
        ttk.Label(self.tree_tab, text='Optimized entropy decision tree', style='Card.TLabel').pack(anchor='w')
        self.tree_text = tk.Text(self.tree_tab, font=('Consolas', 9)); self.tree_text.pack(fill='both', expand=True, pady=8)

    def _build_classify(self):
        form = ttk.Frame(self.classify_tab); form.pack(anchor='center', pady=20)
        self.inputs = {}
        defaults = {'HGB':'12.5','WBC':'7.0','RBC':'4.5','PLT':'220','MCV':'88','MCH':'29','MCHC':'33'}
        for i, feat in enumerate(FEATURES):
            ttk.Label(form, text=feat, width=10).grid(row=i, column=0, sticky='e', padx=8, pady=5)
            e = ttk.Entry(form, width=18); e.insert(0, defaults.get(feat,'')); e.grid(row=i, column=1, padx=8, pady=5); self.inputs[feat] = e
        ttk.Button(form, text='Classify', command=self.classify).grid(row=len(FEATURES), column=0, columnspan=2, pady=15)
        self.prediction = ttk.Label(self.classify_tab, text='Enter CBC values and classify.', font=('Segoe UI', 15, 'bold'), justify='center')
        self.prediction.pack(pady=12)
        ttk.Label(self.classify_tab, text='Demo classification only — not a medical diagnosis.', style='Sub.TLabel').pack()

    def _build_eval(self):
        self.eval_text = tk.Text(self.eval_tab, font=('Consolas', 10)); self.eval_text.pack(fill='both', expand=True)

    def load_and_train(self, path):
        try:
            self.status.config(text=f'Loading {Path(path).name}...')
            df = clean_data(load_dataset(path), FEATURES, TARGET)
            self.df = df
            X = df[FEATURES]; y = df[TARGET]
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2, random_state=42, stratify=y)
            self.result = train(X_train, X_test, y_train, y_test)
            self.test_data = (X_test, y_test)
            self._refresh_all()
            self.status.config(text=f'Trained on {len(df):,} records')
        except Exception as e:
            messagebox.showerror('Training error', str(e)); self.status.config(text='Training failed')

    def load_csv(self):
        path = filedialog.askopenfilename(filetypes=[('CSV files','*.csv')])
        if path: self.load_and_train(path)

    def retrain(self):
        if self.df is not None: self.load_and_train(SAMPLE_DATA)

    def _refresh_all(self):
        r = self.result
        self.metric_labels['rows'].config(text=f'{len(self.df):,}')
        self.metric_labels['classes'].config(text=str(self.df[TARGET].nunique()))
        self.metric_labels['base'].config(text=f'{r.baseline_accuracy:.1%}')
        self.metric_labels['opt'].config(text=f'{r.optimized_accuracy:.1%}')
        self.metric_labels['selected'].config(text=str(len(r.selected_features)))
        self.data_text.delete('1.0','end'); self.data_text.insert('end', self.df.head(25).to_string(index=False))
        self.data_info.config(text=f'{len(self.df)} cleaned rows | {self.df.isna().sum().sum()} missing values | duplicates removed during cleaning')
        self.entropy_text.delete('1.0','end'); self.entropy_text.insert('end', r.ranking.to_string(index=False, formatters={'information_gain':'{:.5f}'.format})); self.entropy_text.insert('end', f'\n\nSelected features:\n{r.selected_features}')
        self.tree_text.delete('1.0','end'); self.tree_text.insert('end', r.tree_text)
        self.eval_text.delete('1.0','end'); self.eval_text.insert('end', r.report_text + '\n\nConfusion matrix / per-class report are shown in the chart.\n\nTarget classes:\n' + '\n'.join(map(str, self.result.model.classes_)))
        self._plot_dashboard(); self._plot_entropy(); self._plot_eval()

    def _clear_frame(self, frame):
        for w in frame.winfo_children(): w.destroy()

    def _plot_dashboard(self):
        self._clear_frame(self.chart_frame)
        fig = Figure(figsize=(8,4), dpi=100); ax = fig.add_subplot(111)
        self.df[TARGET].value_counts().plot(kind='bar', ax=ax)
        ax.set_title('Class Distribution'); ax.set_ylabel('Records'); ax.tick_params(axis='x', rotation=45)
        fig.tight_layout(); canvas=FigureCanvasTkAgg(fig, master=self.chart_frame); canvas.draw(); canvas.get_tk_widget().pack(fill='both', expand=True)

    def _plot_entropy(self):
        self._clear_frame(self.entropy_chart)
        fig=Figure(figsize=(6,5), dpi=100); ax=fig.add_subplot(111)
        rank=self.result.ranking
        ax.barh(rank['feature'][::-1], rank['information_gain'][::-1]); ax.set_title('Entropy-Based Information Gain'); ax.set_xlabel('Information Gain')
        fig.tight_layout(); canvas=FigureCanvasTkAgg(fig, master=self.entropy_chart); canvas.draw(); canvas.get_tk_widget().pack(fill='both', expand=True)

    def _plot_eval(self):
        X_test,y_test=self.test_data; pred=self.result.model.predict(X_test[self.result.selected_features]); labels=list(self.result.model.classes_)
        from sklearn.metrics import confusion_matrix
        cm=confusion_matrix(y_test,pred,labels=labels)
        fig=Figure(figsize=(8,5),dpi=100); ax=fig.add_subplot(111); im=ax.imshow(cm, aspect='auto')
        ax.set_title('Confusion Matrix'); ax.set_xlabel('Predicted'); ax.set_ylabel('Actual'); ax.set_xticks(range(len(labels)), labels, rotation=45, ha='right'); ax.set_yticks(range(len(labels)), labels)
        for i in range(len(labels)):
            for j in range(len(labels)): ax.text(j,i,str(cm[i,j]),ha='center',va='center')
        fig.tight_layout();
        # Add chart to evaluation tab below the report.
        old = getattr(self,'eval_canvas',None)
        if old: old.get_tk_widget().destroy()
        self.eval_canvas=FigureCanvasTkAgg(fig, master=self.eval_tab); self.eval_canvas.draw(); self.eval_canvas.get_tk_widget().pack(fill='both',expand=True)

    def classify(self):
        if self.result is None: return
        try:
            values={f:float(self.inputs[f].get()) for f in FEATURES}
            x=pd.DataFrame([values])
            pred=self.result.model.predict(x[self.result.selected_features])[0]
            probs=self.result.model.predict_proba(x[self.result.selected_features])[0]
            conf=float(np.max(probs)); risk=RISK_MAP.get(str(pred),'Unmapped')
            self.prediction.config(text=f'Predicted classification: {pred}\nDemo risk group: {risk}\nModel confidence: {conf:.1%}')
        except Exception as e:
            messagebox.showerror('Invalid input', f'Please enter numeric CBC values.\n\n{e}')

def run_app():
    SAMPLE_DATA.parent.mkdir(exist_ok=True)
    if not SAMPLE_DATA.exists(): generate_sample_dataset(SAMPLE_DATA)
    root=tk.Tk(); App(root); root.mainloop()
