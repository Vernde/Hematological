import numpy as np
import pandas as pd
from sklearn.feature_selection import mutual_info_classif
from sklearn.preprocessing import LabelEncoder


def entropy(y):
    values, counts = np.unique(y, return_counts=True)
    p = counts / counts.sum()
    return float(-(p * np.log2(p + 1e-12)).sum())


def information_gain(X: pd.DataFrame, y: pd.Series):
    X = X.reset_index(drop=True)
    y = y.reset_index(drop=True)
    base = entropy(y.to_numpy())
    rows = []
    for col in X.columns:
        # Discretize continuous CBC values into quantile bins so entropy-based gain is explicit.
        try:
            bins = pd.qcut(X[col], q=min(8, X[col].nunique()), duplicates='drop')
        except ValueError:
            bins = X[col]
        weighted = 0.0
        for _, idx in pd.Series(bins).groupby(bins, observed=True).groups.items():
            weighted += (len(idx) / len(X)) * entropy(y.iloc[idx].to_numpy())
        rows.append((col, base - weighted))
    return pd.DataFrame(rows, columns=['feature', 'information_gain']).sort_values('information_gain', ascending=False).reset_index(drop=True)


def optimize_features(X: pd.DataFrame, y: pd.Series, min_gain=0.01, max_features=5):
    ranking = information_gain(X, y)
    selected = ranking[ranking['information_gain'] >= min_gain].head(max_features)['feature'].tolist()
    if not selected:
        selected = ranking.head(min(3, len(ranking)))['feature'].tolist()
    return selected, ranking
