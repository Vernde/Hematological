from pathlib import Path
import numpy as np
import pandas as pd

CLASSES = {
    'Healthy': dict(hgb=(13.0, 16.5), wbc=(4.0, 10.0), rbc=(4.4, 5.8), plt=(150, 400), mcv=(80, 100), mch=(27, 33), mchc=(31, 36)),
    'Normocytic normochromic anemia': dict(hgb=(9.0, 12.5), wbc=(4.0, 10.0), rbc=(3.4, 4.6), plt=(140, 350), mcv=(80, 100), mch=(26, 32), mchc=(31, 35)),
    'Normocytic hypochromic anemia': dict(hgb=(7.0, 11.5), wbc=(3.5, 12), rbc=(3.0, 4.6), plt=(90, 300), mcv=(78, 98), mch=(21, 28), mchc=(28, 32)),
    'Iron deficiency anemia': dict(hgb=(6.5, 11.0), wbc=(3.5, 11), rbc=(3.0, 4.8), plt=(70, 400), mcv=(60, 80), mch=(18, 25), mchc=(27, 32)),
    'Other microcytic anemia': dict(hgb=(8.0, 12.0), wbc=(4, 11), rbc=(3.6, 5.4), plt=(100, 350), mcv=(60, 79), mch=(18, 26), mchc=(27, 33)),
    'Macrocytic anemia': dict(hgb=(7.0, 12.0), wbc=(3.0, 11), rbc=(2.8, 4.5), plt=(70, 350), mcv=(101, 115), mch=(30, 36), mchc=(31, 36)),
    'Thrombocytopenia': dict(hgb=(11.0, 16), wbc=(3, 11), rbc=(3.8, 5.6), plt=(30, 130), mcv=(78, 100), mch=(26, 33), mchc=(31, 36)),
    'Leukemia': dict(hgb=(8.0, 15.0), wbc=(12, 35), rbc=(3.5, 5.5), plt=(70, 450), mcv=(75, 105), mch=(24, 34), mchc=(29, 36)),
    'Leukemia with thrombocytopenia': dict(hgb=(7.0, 14.0), wbc=(12, 35), rbc=(3.0, 5.4), plt=(25, 120), mcv=(75, 105), mch=(24, 34), mchc=(29, 36)),
}


def generate_sample_dataset(path: str | Path, n_per_class=100, seed=42):
    rng = np.random.default_rng(seed)
    rows = []
    for label, ranges in CLASSES.items():
        for _ in range(n_per_class):
            row = {}
            for key, (lo, hi) in ranges.items():
                val = rng.normal((lo + hi) / 2, (hi - lo) / 6)
                row[key.upper() if key != 'plt' else 'PLT'] = round(float(np.clip(val, lo, hi)), 3)
            # Add derived-ish differential values to make the dataset closer to CBC records.
            row['Diagnosis'] = label
            rows.append(row)
    df = pd.DataFrame(rows)
    # Keep only the thesis features plus target for a clean MVP.
    df = df[['WBC', 'RBC', 'HGB', 'PLT', 'MCV', 'MCH', 'MCHC', 'Diagnosis']]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return df
