from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / 'data'
MODELS_DIR = ROOT / 'models'
SAMPLE_DATA = DATA_DIR / 'sample_hematology.csv'
MODEL_FILE = MODELS_DIR / 'optimized_decision_tree.joblib'
FEATURE_FILE = MODELS_DIR / 'feature_ranking.csv'

FEATURES = ['HGB', 'WBC', 'RBC', 'PLT', 'MCV', 'MCH', 'MCHC']
TARGET = 'Diagnosis'

# These are presentation/demo groupings, not clinical severity standards.
RISK_MAP = {
    'Healthy': 'Low',
    'Normocytic normochromic anemia': 'Moderate',
    'Normocytic hypochromic anemia': 'Moderate',
    'Iron deficiency anemia': 'Moderate',
    'Other microcytic anemia': 'Moderate',
    'Macrocytic anemia': 'Moderate',
    'Thrombocytopenia': 'High',
    'Leukemia': 'High',
    'Leukemia with thrombocytopenia': 'High',
}
