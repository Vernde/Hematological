from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd


def evaluate(model, X_test, y_test, features):
    pred = model.predict(X_test[features])
    proba = model.predict_proba(X_test[features]) if hasattr(model, 'predict_proba') else None
    cm = confusion_matrix(y_test, pred, labels=model.classes_)
    report = pd.DataFrame(classification_report(y_test, pred, output_dict=True, zero_division=0)).T
    return pred, proba, cm, report
