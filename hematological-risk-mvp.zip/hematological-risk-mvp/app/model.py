from dataclasses import dataclass
import joblib
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import accuracy_score, precision_recall_fscore_support

from .entropy_optimizer import optimize_features

@dataclass
class TrainingResult:
    model: DecisionTreeClassifier
    selected_features: list[str]
    ranking: pd.DataFrame
    baseline_accuracy: float
    optimized_accuracy: float
    report_text: str
    tree_text: str


def train(X_train, X_test, y_train, y_test, max_depth=6):
    baseline = DecisionTreeClassifier(criterion='entropy', max_depth=max_depth, random_state=42, class_weight='balanced')
    baseline.fit(X_train, y_train)
    baseline_pred = baseline.predict(X_test)
    base_acc = accuracy_score(y_test, baseline_pred)

    selected, ranking = optimize_features(X_train, y_train, min_gain=0.01, max_features=min(5, X_train.shape[1]))
    optimized = DecisionTreeClassifier(criterion='entropy', max_depth=max_depth, random_state=42, class_weight='balanced')
    optimized.fit(X_train[selected], y_train)
    pred = optimized.predict(X_test[selected])
    acc = accuracy_score(y_test, pred)
    p, r, f, _ = precision_recall_fscore_support(y_test, pred, average='weighted', zero_division=0)
    report = f'Accuracy: {acc:.3f}\nWeighted precision: {p:.3f}\nWeighted recall: {r:.3f}\nWeighted F1: {f:.3f}'
    tree = export_text(optimized, feature_names=selected)
    return TrainingResult(optimized, selected, ranking, base_acc, acc, report, tree)


def save_bundle(result, path):
    joblib.dump({'model': result.model, 'features': result.selected_features}, path)


def load_bundle(path):
    return joblib.load(path)
