"""Download the public CBC/anemia dataset used as the reference source for this MVP.
Run this script on a machine with internet access. It does not run automatically so the
MVP remains usable offline with the included demo dataset.
"""
from pathlib import Path
import urllib.request

URL = 'https://raw.githubusercontent.com/Nader-ezeldin/anemia-classification/main/diagnosed_cbc_data_v4.csv'
OUT = Path(__file__).parent / 'data' / 'diagnosed_cbc_data_v4.csv'
OUT.parent.mkdir(parents=True, exist_ok=True)
print('Downloading:', URL)
urllib.request.urlretrieve(URL, OUT)
print('Saved to:', OUT)
