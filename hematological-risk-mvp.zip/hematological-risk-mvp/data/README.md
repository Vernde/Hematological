# Dataset

The included `sample_hematology.csv` is a **synthetic demo dataset** generated only so the MVP runs offline immediately.

For a thesis experiment, replace it with the public CBC/anemia dataset referenced in the project README. The project includes `download_dataset.py` to fetch the CSV when internet access is available.

Do not present the synthetic demo records as patient data or clinical ground truth.
