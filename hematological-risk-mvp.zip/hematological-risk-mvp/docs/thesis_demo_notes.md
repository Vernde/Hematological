# Thesis Demo Notes

## One-minute explanation

> "The system accepts hematological CBC data, cleans the records, calculates entropy and information gain for candidate features, removes low-information features, and then constructs an entropy-based Decision Tree using the optimized feature set. The system compares the baseline tree with the optimized tree and presents the classification and evaluation results through a Python desktop interface with Matplotlib visualizations."

## Why entropy-based feature optimization?

The thesis enhancement is not simply using a Decision Tree. The intended contribution is to use entropy/information gain as an explicit feature-optimization stage before tree construction. This creates a measurable comparison between an all-feature baseline and an optimized-feature model.

## What to show if asked about the flowchart

- Input: CBC hematological parameters and a target label.
- Data Processing: clean and normalize the usable numeric values.
- Entropy Computation: calculate parent entropy and weighted child entropy.
- Feature Optimization: rank features by information gain and retain the strongest features.
- Decision Tree Construction: train using `criterion='entropy'`.
- Classification & Evaluation: predict the held-out test set and compute accuracy, precision, recall, F1 and confusion matrix.
- Output: optimized decision tree, classification result, and evaluation report.

## Safe wording

Say **"classification result"**, **"dataset label"**, or **"model prediction"** instead of claiming a diagnosis.

Say **"demo risk grouping"** for the Low/Moderate/High UI mapping. It is not a validated clinical risk score.
